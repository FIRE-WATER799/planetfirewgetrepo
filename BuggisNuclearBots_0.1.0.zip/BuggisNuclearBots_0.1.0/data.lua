require("prototypes.entity.construction-robot")
require("prototypes.entity.logistic-robot")
require("prototypes.technology.nuclear-robots")
require("prototypes.entity.death-explosion")