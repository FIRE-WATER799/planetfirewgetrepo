local button={
    type = "custom-input",
    name = "immolator-active1",
    key_sequence = "SHIFT + F",
    consuming = "none"
}
data:extend{button}