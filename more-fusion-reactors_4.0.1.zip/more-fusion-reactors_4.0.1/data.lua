require("prototypes.item")
require("prototypes.equipment")
require("prototypes.recipe")
require("prototypes.technology")

-- - {Ev modpack tweaks} - --

local tiers = {"mk2", "mk3", "mk4", "mk5", "mk6"}

if mods ["Better-Power-Armor-Grid"] then
    for i, tier in pairs (tiers) do
        data.raw["generator-equipment"]["fusion-reactor-"..tier.."-equipment"].categories = {"armor", "ind_armor"}
    end
end