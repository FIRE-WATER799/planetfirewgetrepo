for index, force in pairs(game.forces) do
  local technologies = force.technologies
  local recipes = force.recipes
  recipes["fusion-reactor-mk2-equipment"].enabled = technologies["productivity-module"].researched
  recipes["fusion-reactor-mk3-equipment"].enabled = technologies["effectivity-module-2"].researched
  recipes["fusion-reactor-mk5-equipment"].enabled = technologies["uranium-processing"].researched
  recipes["fusion-reactor-mk5-equipment"].enabled = technologies["kovarex-enrichment-process"].researched
end