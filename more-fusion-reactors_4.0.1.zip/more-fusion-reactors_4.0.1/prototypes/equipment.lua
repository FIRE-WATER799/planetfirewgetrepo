local mod_name = "__More-Exoskeletons__"
local tiers = {"mk2", "mk3", "mk4", "mk5", "mk6"}
local properties = {
  {"2", "2", "2", "2", "2"}, -- Width
  {"4", "4", "3", "2", "3"}, -- Height
  {"750kW", "1MW", "1.25MW", "1.25MW", "2.5MW"} -- Power Production -- (v4.0.0 Changes: +0kW; +0kW; +0.25kW; +0kW; +0.5kW)
}

data.raw["generator-equipment"]["fusion-reactor-equipment"].sprite.filename = "__more-fusion-reactors__/graphics/equipment/fusion-reactor-equipment.png"
data.raw["generator-equipment"]["fusion-reactor-equipment"].sprite.hr_version.filename = "__more-fusion-reactors__/graphics/equipment/hr-fusion-reactor-equipment.png"

for i, tier in pairs (tiers) do
  data:extend(
  {
	{
	  type = "generator-equipment",
	  name = "fusion-reactor-"..tier.."-equipment",
	  sprite =
	  {
		filename = "__more-fusion-reactors__/graphics/equipment/fusion-reactor-"..tier.."-equipment.png",
		width = 128,
		height = 128,
		priority = "medium",
		hr_version =
		{
		  filename = "__more-fusion-reactors__/graphics/equipment/hr-fusion-reactor-"..tier.."-equipment.png",
		  width = 256,
		  height = 256,
		  priority = "medium",
		  scale = 0.5
		}
	  },
	  shape =
	  {
		width = properties[1][i],
		height = properties[2][i],
		type = "full"
	  },
	  energy_source =
	  {
		type = "electric",
		usage_priority = "primary-output"
	  },
	  power = properties[3][i],
	  categories = {"armor"}
	}
  })
end