data:extend(
{
  {
    type = "recipe",
    name = "fusion-reactor-mk2-equipment",
	  normal =
    {
      enabled = "false",
	    ingredients =
      {
        {"fusion-reactor-equipment", 1}, -- (v4.0.0 Changes: -1)
        {"productivity-module", 5}, -- (v4.0.0 Changes: Introduced)
        {"effectivity-module", 5}
      },
      result = "fusion-reactor-mk2-equipment",
    },
    expensive =
    {
      enabled = "false",
	    ingredients =
      {
        {"fusion-reactor-equipment", 2},
        {"productivity-module", 5}, -- (v4.0.0 Changes: Introduced)
        {"effectivity-module", 5}
      },
      result = "fusion-reactor-mk2-equipment",
    }
  },
  {
    type = "recipe",
    name = "fusion-reactor-mk3-equipment",
	  normal =
    {
      enabled = "false",
      ingredients =
      {
        {"fusion-reactor-mk2-equipment", 1},
        {"productivity-module-2", 5},
        {"effectivity-module-2", 5} -- (v4.0.0 Changes: Introduced)
      },
      result = "fusion-reactor-mk3-equipment",
    },
    expensive =
    {
      enabled = "false",
      ingredients =
      {
        {"fusion-reactor-mk2-equipment", 1},
        {"productivity-module-2", 7}, -- (v4.0.0 Changes: +2)
        {"effectivity-module-2", 7} -- (v4.0.0 Changes: Introduced)
      },
      result = "fusion-reactor-mk3-equipment",
    }
  },
  {
    type = "recipe",
    name = "fusion-reactor-mk4-equipment",
	  normal =
    {
      enabled = "false",
	    ingredients =
      {
        {"fusion-reactor-mk3-equipment", 1},
        {"speed-module-3", 5}
      },
      result = "fusion-reactor-mk4-equipment",
    },
    expensive =
    {
      enabled = "false",
	    ingredients =
      {
        {"fusion-reactor-mk3-equipment", 1},
        {"speed-module-3", 7} -- (v4.0.0 Changes: +2)
      },
      result = "fusion-reactor-mk4-equipment",
    }
  },
  {
    type = "recipe",
    name = "fusion-reactor-mk5-equipment",
	  normal =
    {
      enabled = "false",
	    ingredients = 
      {
        {"fusion-reactor-mk4-equipment", 1},
        {"uranium-238", 5}, -- (v4.0.0 Changes: Introduced)

        {"productivity-module-3", 5}, -- (v4.0.0 Changes: +2)
        {"effectivity-module-3", 5}, -- (v4.0.0 Changes: +2)
        {"speed-module-3", 5} -- (v4.0.0 Changes: +2)
      },
      result = "fusion-reactor-mk5-equipment",
    },
    expensive =
    {
      enabled = "false",
	    ingredients =
      {
        {"fusion-reactor-mk4-equipment", 1},
        {"uranium-238", 10}, -- (v4.0.0 Changes: Introduced)
        
        {"productivity-module-3", 10}, -- (v4.0.0 Changes: +7)
        {"effectivity-module-3", 10}, -- (v4.0.0 Changes: +7)
        {"speed-module-3", 10} -- (v4.0.0 Changes: +7)
      },
      result = "fusion-reactor-mk5-equipment",
    }
  },
  {
    type = "recipe",
    name = "fusion-reactor-mk6-equipment",
    normal =
    {
      enabled = "false",
      ingredients =
      {
        {"fusion-reactor-mk5-equipment", 1},
        {"uranium-235", 3}, -- (v4.0.0 Changes: Introduced)

        {"productivity-module-3", 10}, -- (v4.0.0 Changes: +5)
        {"effectivity-module", 10}, -- (v4.0.0 Changes: +5)
        {"speed-module-3", 10} -- (v4.0.0 Changes: +5)
      },
      result = "fusion-reactor-mk6-equipment",
    },
    expensive =
    {
      enabled = "false",
      ingredients =
      {
        {"fusion-reactor-mk5-equipment", 1},
        {"uranium-235", 5}, -- (v4.0.0 Changes: Introduced)
        
        {"productivity-module-3", 20}, -- (v4.0.0 Changes: +10)
        {"effectivity-module", 20}, -- (v4.0.0 Changes: +10)
        {"speed-module-3", 20} -- (v4.0.0 Changes: +10)
      },
      result = "fusion-reactor-mk6-equipment",
    }
  }

})