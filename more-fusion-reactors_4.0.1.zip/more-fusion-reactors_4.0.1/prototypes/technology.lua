local mod_name = "__More-Exoskeletons__"

data.raw.technology["fusion-reactor-equipment"].icons = util.technology_icon_constant_equipment("__more-fusion-reactors__/graphics/technology/fusion-reactor-equipment.png")
data.raw.technology["fusion-reactor-equipment"].icon_mipmaps = 0

data:extend(
{

  {
    type = "technology",
    name = "fusion-reactor-mk2-equipment",
    icon_size = 256, -- icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment("__more-fusion-reactors__/graphics/technology/fusion-reactor-mk2-equipment.png"),
    prerequisites =
    {
      "fusion-reactor-equipment",
      "productivity-module",
      "effectivity-module"
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "fusion-reactor-mk2-equipment"
      }
    },
    unit =
    {
      count = 250, -- (v4.0.0 Changes: +50)
      ingredients =
      {
        {"automation-science-pack", 2}, -- (v4.0.0 Changes: +1 / +250)
        {"logistic-science-pack", 2}, -- (v4.0.0 Changes: +1 / +250)
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 45 -- (v4.0.0 Changes: -5s)
    },
    order = "g-la"
  },
  {
    type = "technology",
    name = "fusion-reactor-mk3-equipment",
    icon_size = 256, -- icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment("__more-fusion-reactors__/graphics/technology/fusion-reactor-mk3-equipment.png"),
    prerequisites =
    {
      "fusion-reactor-mk2-equipment",
      "productivity-module-2",
      "effectivity-module-2"
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "fusion-reactor-mk3-equipment"
      }
    },
    unit =
    {
      count = 500,
      ingredients =
      {
        {"automation-science-pack", 2}, -- (v4.0.0 Changes: +1 / +500)
        {"logistic-science-pack", 2}, -- (v4.0.0 Changes: +1 / +500)
        {"chemical-science-pack", 2}, -- (v4.0.0 Changes: +1 / +500)
        {"military-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 60 -- (v4.0.0 Changes: -90s)
    },
    order = "g-lb"
  },
  {
    type = "technology",
    name = "fusion-reactor-mk4-equipment",
    icon_size = 256, -- icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment("__more-fusion-reactors__/graphics/technology/fusion-reactor-mk4-equipment.png"),
    prerequisites =
    {
      "fusion-reactor-mk3-equipment",
      "speed-module-3"
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "fusion-reactor-mk4-equipment"
      }
    },
    unit =
    {
      count = 750,
      ingredients =
      {
        {"automation-science-pack", 2}, -- (v4.0.0 Changes: +1 / +750)
        {"logistic-science-pack", 2}, -- (v4.0.0 Changes: +1 / +750)
        {"chemical-science-pack", 2}, -- (v4.0.0 Changes: +1 / +750)
        {"military-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 75 -- (v4.0.0 Changes: -225s)
    },
    order = "g-lc"
  },
  {
    type = "technology",
    name = "fusion-reactor-mk5-equipment",
    icon_size = 256, -- icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment("__more-fusion-reactors__/graphics/technology/fusion-reactor-mk5-equipment.png"),
    prerequisites =
    {
      "fusion-reactor-mk4-equipment",
      "uranium-processing", -- (v4.0.0 Changes: Introduced)

      "productivity-module-3",
      "effectivity-module-3"
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "fusion-reactor-mk5-equipment"
      }
    },
    unit =
    {
      count = 1000,
      ingredients =
      {
        {"automation-science-pack", 3}, -- (v4.0.0 Changes: +2 / +2000)
        {"logistic-science-pack", 3}, -- (v4.0.0 Changes: +2 / +2000)
        {"chemical-science-pack", 2}, -- (v4.0.0 Changes: +1 / +1000)
        {"military-science-pack", 2}, -- (v4.0.0 Changes: +1 / +1000)
        {"production-science-pack", 1}, -- (v4.0.0 Changes: Introduced)
        {"utility-science-pack", 1}
      },
      time = 90 -- (v4.0.0 Changes: -410s)
    },
    order = "g-ld"
  },
  {
    type = "technology",
    name = "fusion-reactor-mk6-equipment",
    icon_size = 256, -- icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment("__more-fusion-reactors__/graphics/technology/fusion-reactor-mk6-equipment.png"),
    prerequisites =
    {
      "fusion-reactor-mk5-equipment",
      "kovarex-enrichment-process", -- (v4.0.0 Changes: Introduced)
      "space-science-pack"
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "fusion-reactor-mk6-equipment"
      }
    },
    unit =
    {
      count = 1000, -- (v4.0.0 Changes: -500) -- Now only a rocket is needed, but there's a price
      ingredients =
      {
        {"automation-science-pack", 3}, -- (v4.0.0 Changes: +2 / +2000)
        {"logistic-science-pack", 3}, -- (v4.0.0 Changes: +2 / +2000)
        {"chemical-science-pack", 2}, -- (v4.0.0 Changes: +1 / +1000)
        {"military-science-pack", 2}, -- (v4.0.0 Changes: +1 / +1000)

        {"production-science-pack", 1}, -- (v4.0.0 Changes: Introduced)
        {"utility-science-pack", 1},
        {"space-science-pack", 1} -- (v4.0.0 Changes: Introduced)
      },
      time = 120 -- (v4.0.0 Changes: -880s)
    },
    order = "g-le"
  }

})