local mod_name = "__More-Exoskeletons__"
local tiers = {"mk2", "mk3", "mk4", "mk5", "mk6"}
local properties = {
  {"20", "15", "15", "10", "10"} -- Stack Sizes -- (v4.0.0 Changes: +0; -5; -15; -35; -40)
}

data.raw.item["fusion-reactor-equipment"].icon = "__more-fusion-reactors__/graphics/item/fusion-reactor-equipment.png"

for i, tier in pairs (tiers) do
	data:extend(
	{
	  {
		type = "item",
		name = "fusion-reactor-"..tier.."-equipment",
		icon = "__more-fusion-reactors__/graphics/item/fusion-reactor-"..tier.."-equipment.png",
		icon_size = 64, icon_mipmaps = 4,
		placed_as_equipment_result = "fusion-reactor-"..tier.."-equipment",
		subgroup = "equipment",
		order = "a[energy-source]-ba[fusion-reactor-"..tier.."-equipment]",
		default_request_amount = 1,
		stack_size = properties[1][i]
	  }
	})
end