mod_name = "__Personal-Roboport-Mk3__"

data.raw.technology["personal-roboport-mk2-equipment"].icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/personal-roboport-mk2-equipment.png"),

data:extend(
{

  {
    type = "technology",
    name = "personal-roboport-mk3-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/personal-roboport-mk3-equipment.png"),
	  effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-roboport-mk3-equipment"
      }
    },
    prerequisites = {"personal-roboport-mk2-equipment", "speed-module-2"},
    unit =
    {
      count = 375, -- -25 (v4.0.0)
      ingredients =
	  {
      {"automation-science-pack", 2},
      {"logistic-science-pack", 2},
      {"chemical-science-pack", 2}, -- +1 (V4.0.0) / +350
      {"production-science-pack", 1},
      {"utility-science-pack", 1}
	  },
      time = 45 -- -25s (V4.0.0)
    },
    order = "a-f-ca"
  },
  {
    type = "technology",
    name = "personal-roboport-mk4-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/personal-roboport-mk4-equipment.png"),
	  effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-roboport-mk4-equipment"
      }
    },
    prerequisites = {"personal-roboport-mk3-equipment", "effectivity-module-2", "productivity-module-2"},
    unit =
    {
      count = 500, -- -100 (v4.0.0)
      ingredients = 
	  {
      {"automation-science-pack", 3},
      {"logistic-science-pack", 3}, -- +1 (v4.0.0) / +300
      {"chemical-science-pack", 3}, -- +1 (v4.0.0) / +300
      {"production-science-pack", 1}, -- -1 (v4.0.0) / -700
      {"utility-science-pack", 1}
	  },
      time = 60 -- -30s (v4.0.0)
    },
    order = "a-f-cb"
  },
  {
    type = "technology",
    name = "personal-roboport-mk5-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/personal-roboport-mk5-equipment.png"),
	  effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-roboport-mk5-equipment"
      }
    },
    prerequisites = {"personal-roboport-mk4-equipment", "speed-module-3"},
    unit =
    {
      count = 750, -- -150 (v4.0.0)
      ingredients = 
	  {
      {"automation-science-pack", 3}, -- +1 (v4.0.0) / +450
      {"logistic-science-pack", 3}, -- +1 (v4.0.0) / +450
      {"chemical-science-pack", 3}, -- +1 (v4.0.0) / +450
      {"production-science-pack", 2},
      {"utility-science-pack", 2}
	  },
      time = 90 -- -30s (v4.0.0)
    },
    order = "a-f-cc"
  },
  {
    type = "technology",
    name = "personal-roboport-mk6-equipment",
    icon_size = 256, icon_mipmaps = 4,
    icons = util.technology_icon_constant_equipment(mod_name.."/graphics/technology/personal-roboport-mk6-equipment.png"),
	  effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-roboport-mk6-equipment"
      }
    },
    prerequisites = {"personal-roboport-mk5-equipment", "effectivity-module-3", "productivity-module-3", "space-science-pack"},
    unit =
    {
      count = 1000, -- -750 (v4.0.0)
      ingredients = 
	  {
      {"automation-science-pack", 4}, -- +2 (v4.0.0) / +2000
      {"logistic-science-pack", 4}, -- +2 (v4.0.0) / +2000
      {"chemical-science-pack", 4}, -- +2 (v4.0.0) / +2000
      {"production-science-pack", 2},
      {"utility-science-pack", 2},
      {"space-science-pack", 1}
	  },
      time = 150 -- +30s (v4.0.0)
    },
    order = "a-f-cd"
  }

})