data:extend(
{

  {
    type = "recipe",
    name = "personal-roboport-mk3-equipment",
    enabled = false,
    energy_required = 30, -- +5s (v4.0.0)
    ingredients =
    {
      {"personal-roboport-mk2-equipment", 4},
      {"low-density-structure", 30},
      {"processing-unit", 120}, -- -20 (v4.0.0)
      {"speed-module-2", 10}
    },
    result = "personal-roboport-mk3-equipment"
  },
  {
    type = "recipe",
    name = "personal-roboport-mk4-equipment",
    enabled = false,
    energy_required = 35, -- +5s (v4.0.0)
    ingredients =
    {
      {"personal-roboport-mk3-equipment", 3}, -- -1 (v4.0.0)
      {"low-density-structure", 100}, -- +50 (v4.0.0)
      {"productivity-module-2", 25}, -- +5 (v4.0.0)
      {"effectivity-module-2", 25}, -- +5 (v4.0.0)
      {"processing-unit", 200} -- +20 (v4.0.0)
    },
    result = "personal-roboport-mk4-equipment"
  },
  {
    type = "recipe",
    name = "personal-roboport-mk5-equipment",
    enabled = false,
    energy_required = 55, -- +20s (v4.0.0)
    ingredients =
    {
      {"personal-roboport-mk4-equipment", 2},
      {"low-density-structure", 125}, -- +50 (v4.0.0)
      {"processing-unit", 225}, -- -25 (v4.0.0)
      {"speed-module-3", 25}
    },
    result = "personal-roboport-mk5-equipment"
  },
  {
    type = "recipe",
    name = "personal-roboport-mk6-equipment",
    enabled = false,
    energy_required = 60, -- +20s (Updated in 4.0.0)
    ingredients =
    {
      {"personal-roboport-mk5-equipment", 1}, -- -1 (v4.0.0)
      {"low-density-structure", 200}, -- +50 (v4.0.0)
      {"productivity-module-3", 35}, -- +5 (v4.0.0)
      {"effectivity-module-3", 35}, -- +5 (v4.0.0)
      {"processing-unit", 350} -- -50 (v4.0.0) / -1035 in total (v4.0.0)
    },
    result = "personal-roboport-mk6-equipment"
  }
  
})