local mod_name = "__Personal-Roboport-Mk3__"
local tiers = {"mk3", "mk4", "mk5", "mk6"}

for i, tier in pairs (tiers) do
	data:extend(
	{
		{
			type = "item",
			name = "personal-roboport-"..tier.."-equipment",
			icon = mod_name.."/graphics/item/personal-roboport-"..tier.."-equipment.png",
			icon_size = 64,
			placed_as_equipment_result = "personal-roboport-"..tier.."-equipment",
			subgroup = "equipment",
			order = "e[robotics]-b[personal-roboport-"..tier.."-equipment]",
			stack_size = 10
		}
	})
end