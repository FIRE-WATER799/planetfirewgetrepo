require("prototypes.item")
require("prototypes.equipment")
require("prototypes.recipe")
require("prototypes.technology")

-- {Balancement of the roboports} --
local tiers = {"mk3", "mk4", "mk5", "mk6"}
stack_sizes = {"10", "10", "5", "5"} -- (Updated in 4.0.0: -5 to all stack sizes)

for i, tier in pairs (tiers) do
    data.raw.item["personal-roboport-"..tier.."-equipment"].stack_size = stack_sizes[i]
end

-- - {Ev modpack tweaks} - --

if mods ["Better-Power-Armor-Grid"] then
  if settings.startup["equipment-division"].value == true then
    for i, tier in pairs (tiers) do 
        data.raw["roboport-equipment"]["personal-roboport-"..tier.."-equipment"].categories = {"ind_armor"}
    end
  else
    for i, tier in pairs (tiers) do 
        data.raw["roboport-equipment"]["personal-roboport-"..tier.."-equipment"].categories = {"armor", "ind_armor"}
    end
  end
end

-- {Graphics and In-Game appearance tier matchings} --
data.raw.item["personal-roboport-mk2-equipment"].icon = mod_name.."/graphics/item/personal-roboport-mk2-equipment.png"
data.raw["roboport-equipment"]["personal-roboport-mk2-equipment"].sprite.filename = mod_name.."/graphics/equipment/personal-roboport-mk2-equipment.png"