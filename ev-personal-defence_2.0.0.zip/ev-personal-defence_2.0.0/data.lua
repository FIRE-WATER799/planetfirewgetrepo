require("prototypes.functions")
require("prototypes.items")
require("prototypes.equipment")
require("prototypes.recipe")
require("prototypes.technology")

-- - {Ev modpack tweaks} - --
local shield_tiers = {"mk3", "mk4", "mk5"}
local laser_equipment_tiers = {"mk2", "mk3", "mk4", "mk5"}

if mods ["Better-Power-Armor-Grid"] then
  if settings.startup["equipment-division"].value == false then
    for i, tier in pairs (shield_tiers) do 
        data.raw["energy-shield-equipment"]["energy-shield-"..tier.."-equipment"].categories = {"armor", "ind_armor"}
    end
    for i, tier in pairs (laser_equipment_tiers) do 
        data.raw["active-defense-equipment"]["personal-laser-defense-"..tier.."-equipment"].categories = {"armor", "ind_armor"}
    end
  end
  
  evanilla.tech.add_prerequisite("energy-shield-mk3-equipment", "power-armor-mk3")
  evanilla.tech.add_prerequisite("energy-shield-mk4-equipment", "power-armor-mk4")
  evanilla.tech.add_prerequisite("energy-shield-mk5-equipment", "power-armor-mk5")
end

if mods ["more-fusion-reactors"] then
  evanilla.tech.add_prerequisite("energy-shield-mk4-equipment", "fusion-reactor-equipment-4")
end