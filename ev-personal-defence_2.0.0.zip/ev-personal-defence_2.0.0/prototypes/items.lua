local mod_name = "__ev-personal-defence__"
local shield_tiers = {"mk3", "mk4", "mk5"}
local laser_equipment_tiers = {"mk2", "mk3", "mk4", "mk5"}
local properties = {
  {"15", "15", "10"}, -- (v2.0.0 Changes: -5; -5; -10)
  {"20", "15", "15", "10"} -- (v2.0.0 Changes: +0; -5; -5; -10)
}

for i, shield_tier in pairs (shield_tiers) do
  data:extend({
    {
      type = "item",
      name = "energy-shield-"..shield_tier.."-equipment",
      localised_description = {"item-description.energy-shield-equipment"},
		  icon = mod_name.."/graphics/icons/energy-shield-"..shield_tier.."-equipment.png",
      icon_size = 64, icon_mipmaps = 4,
      placed_as_equipment_result = "energy-shield-"..shield_tier.."-equipment",
      subgroup = "military-equipment",
      order = "aa[energy-shield-equipment-mk2]-ab[energy-shield-equipment-"..shield_tier.."]",
      default_request_amount = 10, -- (v2.0.0 Changes: +5)
      stack_size = properties[1][i]
    }
  })
end

for i, laser_tier in pairs (laser_equipment_tiers) do
  data:extend({
    {
      type = "item",
      name = "personal-laser-defense-"..laser_tier.."-equipment",
      localised_description = {"item-description.personal-laser-equipment"},
		  icon = mod_name.."/graphics/icons/personal-laser-defense-"..laser_tier.."-equipment.png",
      icon_size = 64, icon_mipmaps = 4,
      placed_as_equipment_result = "personal-laser-defense-"..laser_tier.."-equipment",
      subgroup = "military-equipment",
      order = "b[active-defense]-ab[personal-laser-defense-"..laser_tier.."-equipment]",
      default_request_amount = 5,
      stack_size = properties[2][i]
    }
  })
end