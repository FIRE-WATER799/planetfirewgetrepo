local mod_name = "__ev-personal-defence__"

data:extend(
{
    
  {
    type = "technology",
    name = "energy-shield-mk3-equipment",
    icon_size = 128,
    icon = mod_name.."/graphics/technology/energy-shield-mk3-equipment.png",
    prerequisites = {"energy-shield-mk2-equipment", "military-4", "power-armor-mk2"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "energy-shield-mk3-equipment"
      }
    },
    unit =
    {
      count = 350,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1}
      },
      time = 40
    },
    order = "g-e-b-a"
  },
    
  {
    type = "technology",
    name = "energy-shield-mk4-equipment",
    icon_size = 128,
    icon = mod_name.."/graphics/technology/energy-shield-mk4-equipment.png",
    prerequisites = {"energy-shield-mk3-equipment"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "energy-shield-mk4-equipment"
      }
    },
    unit =
    {
      count = 500,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 40
    },
    order = "g-e-b-a"
  },
  {
    type = "technology",
    name = "energy-shield-mk5-equipment",
    icon_size = 128,
    icon = mod_name.."/graphics/technology/energy-shield-mk5-equipment.png",
    prerequisites = {"energy-shield-mk4-equipment"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "energy-shield-mk5-equipment"
      }
    },
    unit =
    {
      count = 750,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 50
    },
    order = "g-e-b-a"
  },
  
})

data:extend(
{

  {
    type = "technology",
    name = "personal-laser-defense-mk2-equipment",
    icon_size = 128,
    icon = mod_name.."/graphics/technology/personal-laser-defense-mk2-equipment.png",
    prerequisites = {"speed-module", "personal-laser-defense-equipment"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-laser-defense-mk2-equipment"
      }
    },
    unit =
    {
      count = 250,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1}
      },
      time = 45
    },
    order = "g-m-a"
  },
  {
    type = "technology",
    name = "personal-laser-defense-mk3-equipment",
    icon_size = 128,
    icon = mod_name.."/graphics/technology/personal-laser-defense-mk3-equipment.png",
    prerequisites = {"power-armor-mk2", "personal-laser-defense-mk2-equipment", "speed-module-2"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-laser-defense-mk3-equipment"
      }
    },
    unit =
    {
      count = 300,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"utility-science-pack", 1},
      },
      time = 60
    },
    order = "g-m-c"
  },
  {
    type = "technology",
    name = "personal-laser-defense-mk4-equipment",
    icon_size = 128,
    icon = mod_name.."/graphics/technology/personal-laser-defense-mk4-equipment.png",
    prerequisites = {"personal-laser-defense-mk3-equipment", "speed-module-3"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-laser-defense-mk4-equipment"
      }
    },
    unit =
    {
      count = 500,
      ingredients =
      {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2},
        {"military-science-pack", 2},
        {"chemical-science-pack", 1},
        {"utility-science-pack", 1},
      },
      time = 60
    },
    order = "g-m-d"
  },
  {
    type = "technology",
    name = "personal-laser-defense-mk5-equipment",
    icon_size = 128,
    icon = mod_name.."/graphics/technology/personal-laser-defense-mk5-equipment.png",
    prerequisites = {"personal-laser-defense-mk4-equipment", "fusion-reactor-equipment"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "personal-laser-defense-mk5-equipment"
      }
    },
    unit =
    {
      count = 750,
      ingredients =
      {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2},
        {"military-science-pack", 2},
        {"chemical-science-pack", 1},
        {"utility-science-pack", 1},
      },
      time = 60
    },
    order = "g-m-d"
  },
  
})

if mods ["more-fusion-reactors"] then

  evanilla.tech.add_prerequisite("personal-laser-defense-mk5-equipment", "fusion-reactor-mk4-equipment")

end