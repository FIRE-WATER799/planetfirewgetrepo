data:extend(
{

  {
    type = "recipe",
    name = "energy-shield-mk3-equipment",
    enabled = false,
    energy_required = 15,
    ingredients =
    {
      {"energy-shield-mk2-equipment", 6},
      {"processing-unit", 15},
      {"low-density-structure", 15}
    },
    result = "energy-shield-mk3-equipment"
  },

  {
    type = "recipe",
    name = "energy-shield-mk4-equipment",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"energy-shield-mk3-equipment", 5},
      {"processing-unit", 20},
      {"low-density-structure", 20},

      {"effectivity-module-2", 3}
    },
    result = "energy-shield-mk4-equipment"
  },

  {
    type = "recipe",
    name = "energy-shield-mk5-equipment",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"energy-shield-mk4-equipment", 4},
      {"processing-unit", 20},
      {"low-density-structure", 30},

      {"effectivity-module-3", 5}
    },
    result = "energy-shield-mk5-equipment"
  }
	
})

data:extend(
{

  {
    type = "recipe",
    name = "personal-laser-defense-mk2-equipment",
    enabled = false,
    energy_required = 15,
    ingredients =
    {
      {"processing-unit", 30},
      {"low-density-structure", 10},
      {"personal-laser-defense-equipment", 5},
      
      {"speed-module", 2}
    },
    result = "personal-laser-defense-mk2-equipment"
  },

  {
    type = "recipe",
    name = "personal-laser-defense-mk3-equipment",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"processing-unit", 35},
      {"low-density-structure", 15},
      {"personal-laser-defense-mk2-equipment", 4},
      
      {"speed-module-2", 5}
    },
    result = "personal-laser-defense-mk3-equipment"
  },

  {
    type = "recipe",
    name = "personal-laser-defense-mk4-equipment",
    enabled = false,
    energy_required = 25,
    ingredients =
    {
      {"processing-unit", 40},
      {"low-density-structure", 20},
      {"personal-laser-defense-mk3-equipment", 3},
      
      {"speed-module-3", 10}
    },
    result = "personal-laser-defense-mk4-equipment"
  },

  {
    type = "recipe",
    name = "personal-laser-defense-mk5-equipment",
    enabled = false,
    energy_required = 40,
    ingredients =
    {
      {"processing-unit", 50},
      {"low-density-structure", 30},

      {"personal-laser-defense-mk4-equipment", 2},
      {"fusion-reactor-equipment", 1},
      
      {"speed-module-3", 15}
    },
    result = "personal-laser-defense-mk5-equipment"
  },
  
})

if mods ["more-fusion-reactors"] then
  data.raw["recipe"]["personal-laser-defense-mk5-equipment"].ingredients[4][1] = "fusion-reactor-mk4-equipment"
end