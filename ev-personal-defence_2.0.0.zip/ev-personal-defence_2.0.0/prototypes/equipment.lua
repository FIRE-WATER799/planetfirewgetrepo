local mod_name = "__ev-personal-defence__"
local laser_equipment_tiers = {"mk2", "mk3", "mk4", "mk5"}
local shield_tiers = {"mk3", "mk4", "mk5"}

local shield_properties = {
  {"3", "4", "3"}, -- tier_size -- {Custom value} --
  {"300", "400", "500"}, -- tier_max_shield_value -- {Custom value} --
  {"260kJ", "420kJ", "675kJ"}, -- tier_buffer_capacity -- {Half of the tier_input_flow_limit} --
  {"520kW", "840kW", "1350kW"}, -- tier_input_flow_limit -- {Tier_energy_per_shield / Tier_input_flow_limit = Health regen/s} --
  {"40kJ", "60kJ", "90kJ",} -- tier_energy_per_shield -- {Tier_max_shield_value / 5} --
}
local laser_properties = {
    {"2", "3", "3", "2"},  -- Laser Size
    {"440kJ", "660kJ", "880kJ", "550kJ"},  -- laser_buffer_capacity
    {"100kJ", "150kJ", "200kJ", "25kJ"},  -- laser_consumption
    {"3.25", "3.5", "3.75", "4"},  -- laser_damage_modifier
    {"17.5", "20", "22.5", "27.5"},  -- laser_range
    {"30", "27.5", "22.5", "17.5"}  -- laser_cooldown
}

for i, shield_tier in pairs (shield_tiers) do
  data:extend(
  {
    {
      type = "energy-shield-equipment",
      name = "energy-shield-"..shield_tier.."-equipment",
      sprite =
      {
        filename = mod_name.."/graphics/equipment/energy-shield-"..shield_tier.."-equipment.png",
        width = 64,
        height = 64,
        priority = "medium",
        hr_version =
        {
          filename = mod_name.."/graphics/equipment/hr-energy-shield-"..shield_tier.."-equipment.png",
          width = 128,
          height = 128,
          priority = "medium",
          scale = 0.5
        }
      },
      shape =
      {
        width = shield_properties[1][i],
        height = shield_properties[1][i],
        type = "full"
      },
      max_shield_value = shield_properties[2][i],
      energy_source =
      {
        type = "electric",
        buffer_capacity = shield_properties[3][i],
        input_flow_limit = shield_properties[4][i],
        usage_priority = "primary-input"
      },
      energy_per_shield = shield_properties[5][i],
      categories = {"armor"}
    }
  })
end

for i, laser_tier in pairs (laser_equipment_tiers) do
  data:extend(
  {
    {
      type = "active-defense-equipment",
      name = "personal-laser-defense-"..laser_tier.."-equipment",
      sprite =
      {
        filename = mod_name.."/graphics/equipment/personal-laser-defense-"..laser_tier.."-equipment.png",
        width = 64,
        height = 64,
        priority = "medium",
        hr_version =
        {
          filename = mod_name.."/graphics/equipment/hr-personal-laser-defense-"..laser_tier.."-equipment.png",
          width = 128,
          height = 128,
          priority = "medium",
          scale = 0.5
        }
      },
      shape =
      {
        width = laser_properties[1][i],
        height = laser_properties[1][i],
        type = "full"
      },
      energy_source =
      {
        type = "electric",
        usage_priority = "secondary-input",
        buffer_capacity = laser_properties[2][i]
      },
  
      attack_parameters =
      {
        type = "beam",
        cooldown = laser_properties[6][i],
        range = laser_properties[5][i],
        damage_modifier = laser_properties[4][i],
        ammo_type =
        {
          category = "laser",
          energy_consumption = laser_properties[3][i],
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "beam",
              beam = "laser-beam",
              max_length = laser_properties[5][i],
              duration = laser_properties[6][i],
              source_offset = {0, -1.31439 }
            }
          }
        }
      },
  
      automatic = true,
      categories = {"armor"}
    }
  })
end

