data:extend(
{
  {
    type = "string-setting",
    name = "idle-crafter-product-or-recipe-names",
    order = "a",
    setting_type = "runtime-per-user",
    default_value = "",
    allow_blank = true
  }
})