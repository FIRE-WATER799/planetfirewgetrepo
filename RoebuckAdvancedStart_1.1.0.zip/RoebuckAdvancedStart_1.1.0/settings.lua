data:extend({
   {
       type = "bool-setting",
       name = "roebuck-advanced-start-armor",
       setting_type = "runtime-global",
       default_value = true,
       order = "a"
   },
   {
       type = "bool-setting",
       name = "roebuck-advanced-start-intermediates",
       setting_type = "runtime-global",
       default_value = true,
       order = "b"
   },
   {
       type = "bool-setting",
       name = "roebuck-advanced-start-production",
       setting_type = "runtime-global",
       default_value = true,
       order = "c"
   },
   {
       type = "bool-setting",
       name = "roebuck-advanced-start-logistics",
       setting_type = "runtime-global",
       default_value = true,
       order = "d"
   },
   {
       type = "bool-setting",
       name = "roebuck-advanced-start-car",
       setting_type = "runtime-global",
       default_value = true,
       order = "e"
   },
   {
       type = "bool-setting",
       name = "roebuck-advanced-start-research-toolbelt",
       setting_type = "runtime-global",
       default_value = true,
       order = "f"
   }
})