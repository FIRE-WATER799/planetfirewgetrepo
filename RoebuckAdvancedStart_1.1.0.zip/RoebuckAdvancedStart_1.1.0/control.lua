require("lib")


function Init()
	global = {}
	global.PlayerList = {}
end

function CheckAllPlayers()
	for _,player in pairs(game.players) do
		if player and player.connected then
			GiveArmor(player)		
		end
	end
end

function OnInit()
	Init()
	CheckAllPlayers()
end
script.on_init(OnInit)

function OnPlayerSpawned(event)
	local player = game.get_player(event.player_index)
	GiveArmor(player)
end	
--script.on_event({defines.events.on_player_joined_game,defines.events.on_player_created,},OnPlayerSpawned)
script.on_event({defines.events.on_player_created,},OnPlayerSpawned)

function GiveArmor(player)
	player.print("Giving Armor")
	if Contains(global.PlayerList,player) then return end
	if (player.controller_type ~= defines.controllers.character) then return end

	on_player_creation(player)

	table.insert(global.PlayerList,player)

end

-- fires on the end of the cutscene (singleplayer)
script.on_event(defines.events.on_cutscene_cancelled, function(event)

	local player = game.players[event.player_index]
	on_player_creation(player)

end)


-- list of items
	local armor_items = {
		{"pamk3-pamk4", 1},
		{"energy-shield-mk5-equipment", 20},
		{"fusion-reactor-mk6-equipment", 20},
		{"construction-robot-nuclear", 500},
		{"exoskeleton-equipment", 60},
		{"personal-roboport-mk6-equipment", 5},
		{"pamk3-battmk3", 50}
	}

	local armor = {
		{"personal-roboport-mk6-equipment"},
		{"fusion-reactor-mk6-equipment"},
		{"fusion-reactor-mk6-equipment"},
		{"fusion-reactor-mk6-equipment"},
		{"fusion-reactor-mk6-equipment"},	
		{"fusion-reactor-mk6-equipment"},
		{"fusion-reactor-mk6-equipment"},	
		{"fusion-reactor-mk6-equipment"},
		{"fusion-reactor-mk6-equipment"},	
		{"fusion-reactor-mk6-equipment"},
		{"fusion-reactor-mk6-equipment"},	
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},
		{"energy-shield-mk5-equipment"},		
		{"personal-laser-defense-mk5-equipment"},
		{"personal-laser-defense-mk5-equipment"},
		{"personal-laser-defense-mk5-equipment"},
		{"personal-laser-defense-mk5-equipment"},
		{"personal-laser-defense-mk5-equipment"},
		{"personal-laser-defense-mk5-equipment"},
		{"personal-laser-defense-mk5-equipment"},
		{"personal-laser-defense-mk5-equipment"},
		{"personal-laser-defense-mk5-equipment"},
		{"personal-laser-defense-mk5-equipment"},		
		{"exoskeleton-equipment"},	
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},	
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},	
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},	
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},
		{"exoskeleton-equipment"},	
		{"pamk3-battmk3"},
		{"pamk3-battmk3"},
		{"pamk3-battmk3"},
		{"pamk3-battmk3"}
		
	}

	local intermediates = {
		{"iron-plate", 600},
		{"copper-plate", 400},
		{"electronic-circuit", 400},
		{"iron-gear-wheel", 400}
	}

	local production = {
		{"steel-furnace", 400},
		{"inserter", 800},
		{"assembling-machine-3", 200},
		{"electric-mining-drill", 200},
		{"boiler", 20},
		{"steam-engine", 50},
		{"offshore-pump", 1}
	}

	local logistics = {
		{"transport-belt", 1100},
		{"underground-belt", 100},
		{"splitter", 50},
		{"inserter", 200},
		{"long-handed-inserter", 50},
		{"steel-chest", 50},
		{"medium-electric-pole", 400},
		{"pipe-to-ground", 50},
		{"pipe", 200},
		{"small-lamp", 100}
	}

	local car = {
		{"spidertronmk3", 2}
	}



function on_player_creation(player)
	
	if settings.global["roebuck-advanced-start-armor"].value then
		give_player_items(player, armor_items)
		local grid = player.get_inventory(defines.inventory.character_armor)[1].grid
		for  i, v in pairs(armor) do
			grid.put({name = v[1]})
		end	
	end

	if settings.global["roebuck-advanced-start-intermediates"].value then
		give_player_items(player, intermediates)
	end

	if settings.global["roebuck-advanced-start-production"].value then
		give_player_items(player, production)
	end
	if settings.global["roebuck-advanced-start-logistics"].value then
		give_player_items(player, logistics)
	end
	if settings.global["roebuck-advanced-start-car"].value then
		give_player_items(player, car)
	end
	if settings.global["roebuck-advanced-start-research-toolbelt"].value then
		player.force.technologies["toolbelt"].researched = true
	end
end


function give_player_items(player, items) 
	for i, v in pairs(items) do
		player.insert{name = v[1], count = v[2]}
	end
end
